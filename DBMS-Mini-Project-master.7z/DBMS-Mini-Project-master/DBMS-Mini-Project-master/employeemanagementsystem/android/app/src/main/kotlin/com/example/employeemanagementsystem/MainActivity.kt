package com.example.employeemanagementsystem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
